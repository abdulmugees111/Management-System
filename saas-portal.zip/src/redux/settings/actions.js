const actions = {
  SET_STATE: 'settings/SET_STATE',
  CHANGE_SETTING: 'settings/CHANGE_SETTING',
  SET_PRIMARY_COLOR: 'settings/SET_PRIMARY_COLOR',
  SET_THEME: 'settings/SET_THEME',
  CHANGE_LOCALE:"CHANGE_LOCALE"
}

export default actions

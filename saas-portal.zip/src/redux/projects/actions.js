const actions = {
  SET_STATE: 'projects/SET_STATE',
  GET_ALL_PROJECTS: 'projects/GET_ALL_PROJECTS',
  GET_PROJECT: 'projects/GET_PROJECT',
}

export default actions

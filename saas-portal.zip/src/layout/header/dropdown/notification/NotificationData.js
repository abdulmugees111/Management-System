const data = {
  title: "Notifications",
  notification: [
    {
      id: "note106",
      icon: "curve-down-right",
      iconStyle: "bg-warning-dim",
      text: "You have requested to Widthdraw",
      time: "2",
    },
    {
      id: "note105",
      icon: "curve-down-left",
      iconStyle: "bg-success-dim",
      text: "Your Deposit Order is placed",
      time: "5",
    },
    {
      id: "note104",
      icon: "curve-down-right",
      iconStyle: "bg-warning-dim",
      text: "You have requested to Widthdraw",
      time: "7",
    },
    {
      id: "note103",
      icon: "curve-down-left",
      iconStyle: "bg-success-dim",
      text: "Your Deposit Order is placed",
      time: "8",
    },
    {
      id: "note102",
      icon: "curve-down-right",
      iconStyle: "bg-warning-dim",
      text: "You have requested to Widthdraw",
      time: "11",
    },
    {
      id: "note101",
      icon: "curve-down-left",
      iconStyle: "bg-success-dim",
      text: "Your Deposit Order is placed",
      time: "12",
    },
  ],
};
export default data;
